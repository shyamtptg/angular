import { DialogpipePipe } from './hardware-management-dialog.pipe';

describe('DialogpipePipe', () => {
  it('create an instance', () => {
    const pipe = new DialogpipePipe();
    expect(pipe).toBeTruthy();
  });
});
